from .customer_router import customer_router
from .order_router import order_router  # 👈 This line must be present
